In this directory, the files **10.pan_pairs_features.zip** and **11.pan_pairs_mean_feature.zip** from figshare need to be unzipped and placed here for model training.
