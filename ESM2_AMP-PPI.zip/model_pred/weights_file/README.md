## Trained model weights file
Place the three files from [figshare](https://figshare.com/articles/dataset/ESM2_AMP/28378157)—2.ESM2_AMPS.pth, 3.ESM2_AMP_CSE.pth, and 4.ESM2_DPM.pth—here.
