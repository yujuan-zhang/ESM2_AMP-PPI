Integrated_Gradients of ESM2_AMPS and ESM2_AMP_CSE models.

**Note:**Since the baseline is calculated by randomly selected samples when computing the IG values, the final IG values may vary. However, the fundamental point we aim to convey remains valid.
