cls segment0-9 eos AE_RF_Gini
