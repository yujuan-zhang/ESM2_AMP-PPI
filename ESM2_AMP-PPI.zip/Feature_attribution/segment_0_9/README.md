The model of this process only contains Segment 0-9 features.
