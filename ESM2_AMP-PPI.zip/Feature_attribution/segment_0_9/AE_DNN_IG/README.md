segment0-9 AE_DNN_IG
