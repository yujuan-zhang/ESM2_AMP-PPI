AE_DNN model (only segment0-9)
