segment0-9 AE_RF_Gini
