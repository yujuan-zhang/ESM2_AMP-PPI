The protein pairs features of Bernett dataset.

Please place the two folders (bernett_seg_train_val and bernett_seg_test) extracted from the file **11.Bernett_dataset_features.zip** in [figshare](https://figshare.com/articles/dataset/ESM2_AMP/28378157) here.
