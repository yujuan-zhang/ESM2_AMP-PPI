The model file of ESM2_AMPS trained on the training set of the Bernett dataset.

You need to extract the contents of **5.ESM2_AMPS_Bernett.zip** from [figshare](https://figshare.com/articles/dataset/ESM2_AMP/28378157) and place them here, ensuring that the 5.ESM2_AMPS_Bernett directory itself is not included.
