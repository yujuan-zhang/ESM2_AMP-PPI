Training, validation and testing of the ESM2_AMPS model in the Bernett dataset.
