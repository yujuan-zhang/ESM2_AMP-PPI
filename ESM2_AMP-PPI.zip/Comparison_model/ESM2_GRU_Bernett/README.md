Training, validation and testing of the ESM2_GRU model in the Bernett dataset.
