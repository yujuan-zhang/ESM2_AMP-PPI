The model file of ESM2_GRU trained on the training set of the Bernett dataset.

You need to extract the contents of **6.ESM2_GRU_Bernett.zip** from [figshare](https://figshare.com/articles/dataset/ESM2_AMP/28378157) and place them here, ensuring that the 6.ESM2_GRU_Bernett directory itself is not included.
