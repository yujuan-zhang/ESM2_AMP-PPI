The model performance is compared using the Bernett dataset.
