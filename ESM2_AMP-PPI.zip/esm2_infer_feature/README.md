The process involves the ESM2_650M model extracting features.
In the **data** directory under this folder, we have provided some proteins and their sequences as examples. After running the **esm2_infer_features_example.py** script, the feature files are saved in the **output** directory under this folder.
You can also replace the proteins and sequences in the data directory with your own protein samples for feature extraction.
