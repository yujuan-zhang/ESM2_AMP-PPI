This directory contains the encapsulated drawing and calculation functions.
