Identification computational methods of functional amino acid regions
