This directory provides information on the functional regions of protein sequences from **UniProt** and **InterPro** databases.
