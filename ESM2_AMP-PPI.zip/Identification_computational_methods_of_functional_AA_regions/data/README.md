This directory contains the segmentation and feature importance of the samples in the dataset.
